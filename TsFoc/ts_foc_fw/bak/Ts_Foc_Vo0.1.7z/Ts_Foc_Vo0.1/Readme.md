# Ts_Foc_Vo1_0

##### 说明

1. 基于先前单路Ts_Foc驱动器改进带mcu控制器驱动器
2. 支持CANHD、USB、USART通讯方式
3. 支持电流检测
4. 支持双路电机控制
5. 布局参考Odriver3.6
6. PCB完全使用kicad8.7设计