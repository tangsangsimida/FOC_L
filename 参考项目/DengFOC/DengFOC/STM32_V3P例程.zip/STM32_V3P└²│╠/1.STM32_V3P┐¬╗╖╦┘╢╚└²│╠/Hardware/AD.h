#ifndef __AD_H
#define __AD_H

extern uint16_t Samp_volts[2];

void AD_Init(void);

#endif


