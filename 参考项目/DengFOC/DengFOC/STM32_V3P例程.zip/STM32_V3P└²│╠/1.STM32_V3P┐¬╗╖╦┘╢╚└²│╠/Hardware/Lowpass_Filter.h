#ifndef __LOWPASS_FILTER_H
#define __LOWPASS_FILTER_H


float Lowpassfilter(float Tf, float x);
float Lowpassfilter_sim(float x);



#endif


