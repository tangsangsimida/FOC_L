#ifndef __PWM_H
#define __PWM_H


void PWM_Init(void);
void PWM_Channel1(float Compare);
void PWM_Channel2(float Compare);
void PWM_Channel3(float Compare);

#endif


