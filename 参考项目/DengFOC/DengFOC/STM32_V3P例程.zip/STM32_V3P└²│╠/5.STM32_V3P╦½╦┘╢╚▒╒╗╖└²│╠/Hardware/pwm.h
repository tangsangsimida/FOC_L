#ifndef __PWM_H
#define __PWM_H


void PWM_Init(void);
void M0_PWM_A(float Compare);
void M0_PWM_B(float Compare);
void M0_PWM_C(float Compare);
void M1_PWM_A(float Compare);
void M1_PWM_B(float Compare);
void M1_PWM_C(float Compare);

#endif


